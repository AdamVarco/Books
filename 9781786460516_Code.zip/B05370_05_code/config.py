#Configuration file to work with Email recipes
fromaddr = "<your gmail address>"
password = "<your password>"
toaddr = "<to address>"


