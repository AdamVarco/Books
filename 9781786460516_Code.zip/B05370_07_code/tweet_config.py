offers_sydney = {
    "content":"Weekend Offers, avail 30% discount today!",
    "day":"2016-08-27",
    "time":"13:25",
    "timezone":"Australia/Sydney"
}

post_newyork = {
    "content":"Introducing sun glasses at your favorite stores in NY!",
    "day":"2016-08-27",
    "time":"12:41",
    "timezone":"America/New_York"
}

scheduled_messages = [offers_sydney, post_newyork]


