#Example of working with Calendar
import calendar
from calendar import TextCalendar
cal = TextCalendar()

#Returns the calender for the year 2017
cal.pryear(2017)

#Returns the calender for the month of Novemeber in 2017
cal.prmonth(2017, 11)

